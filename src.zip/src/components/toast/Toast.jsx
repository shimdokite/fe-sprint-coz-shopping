import React, { useEffect, useState } from "react";
import styled, { keyframes, css } from "styled-components";
import iconOn from "../../assets/iconOn.png";
// import iconOff from "../../assets/iconOff.png";

export const Toast = ({ onClose }) => {
  useEffect(() => {
    // 토스트가 보여진 후 2초 뒤에 자동으로 사라지도록 설정
    const timer = setTimeout(() => {
      onClose();
    }, 2000);

    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <>
      <ToastContainer>
        <ToastCheackImg />
        <ToastDescription>북마크가 추가되었습니다.</ToastDescription>
      </ToastContainer>
    </>
  );
};

const show = keyframes`
    from {
        transform: translateX(100%);
    } to {
        opacity: 1;
        transform: translateX(0px);
    }
`;

const ToastContainer = styled.div`
  animation: ${show} 1.5s ease-in-out;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 8px;
  border: 1px solid #0000001a;
  border-radius: 12px;

  width: 291px;
  height: 52px;

  padding: 18px 24px;
  box-shadow: 0 0 8px rgba(0, 0, 0, 0.2);

  ${(props) =>
    props.isFading &&
    css`
      opacity: 0;
      transform: opacity 1.5s ease-in-out;
    `}
`;

const ToastCheackImg = styled.img.attrs({
  src: `${iconOn}`,
})`
  /* cursor: pointer; */

  width: 18px;
  height: 18px;
`;

const ToastDescription = styled.div`
  font-weight: 700;
  /* text-align: center; */
`;
