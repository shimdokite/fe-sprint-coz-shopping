import { useRef } from "react";

export default function useIntersectionObserver(callback) {
  const observer = useRef(
    new IntersectionObserver(
      (entries, observer) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            callback();
          }
        });
      },
      { threshold: 1 }
    )
  );

  const observe = (element) => {
    observer.current.observe(element);
  };

  const unobserve = (element) => {
    observer.current.unobserve(element);
  };

  return [observe, unobserve];
}

// import React, { useState, useEffect, useRef } from 'react';

// const InfiniteScroll = () => {
//   const [data, setData] = useState([]);
//   const [isLoading, setIsLoading] = useState(false);
//   const observerRef = useRef();

//   const fetchData = () => {
//     // 여기에서 새 데이터를 로드하는 API 호출 또는 데이터 소스로 교체합니다.
//     // 이 예제에서는 간단하게 임의의 데이터를 생성하여 사용합니다.
//     setIsLoading(true);
//     setTimeout(() => {
//       const newData = Array.from({ length: 10 }, (_, index) => data.length + index + 1);
//       setData((prevData) => prevData.concat(newData));
//       setIsLoading(false);
//     }, 1000);
//   };

//   const handleIntersection = (entries) => {
//     const target = entries[0];
//     if (target.isIntersecting && !isLoading) {
//       fetchData();
//     }
//   };

//   useEffect(() => {
//     const options = {
//       root: null,
//       rootMargin: '0px',
//       threshold: 1.0,
//     };
//     observerRef.current = new IntersectionObserver(handleIntersection, options);

//     if (observerRef.current && data.length === 0) {
//       fetchData();
//     }

//     return () => {
//       if (observerRef.current) {
//         observerRef.current.disconnect();
//       }
//     };
//   }, [data, isLoading]);

//   return (
//     <div>
//       <h1>Infinite Scroll Example</h1>
//       <ul style={{ listStyle: 'none', padding: 0 }}>
//         {data.map((item) => (
//           <li key={item} style={{ padding: '8px' }}>
//             {item}
//           </li>
//         ))}
//         {isLoading && <li>Loading...</li>}
//         <li ref={(element) => observerRef.current.observe(element)} />
//       </ul>
//     </div>
//   );
// };

// export default InfiniteScroll;
