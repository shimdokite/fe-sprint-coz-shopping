import { styled } from "styled-components";

const Notification = ({ notification }) => {
  const [toastList, setToastList] = useState();

  useEffect(() => {
    setToastList([...notification]);
  }, [notification]);

  return (
    <Notifications>
      {toastList?.map((item, index) => (
        <Toast key={index} item={item} />
      ))}
    </Notifications>
  );
};

const Notifications = styled.div``;
