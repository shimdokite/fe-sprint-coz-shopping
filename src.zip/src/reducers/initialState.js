export const initialState = {};
